# The Iver & Solien Manifesto

This project includes the full manifesto, a beautiful React website, and downloadable versions.

## Files

- `manifesto.pdf`
- `manifesto.md`
